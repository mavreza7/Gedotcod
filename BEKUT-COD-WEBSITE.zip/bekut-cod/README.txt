BEKUT COD — WEBSITE MOTOR CUSTOM

CARA PAKAI:
1. Ekstrak folder/ZIP ini.
2. Buka index.html untuk preview di browser.
3. Edit script.js, ganti WHATSAPP_NUMBER dengan nomor admin.
   Contoh: 628123456789 (tanpa +, spasi, atau 0 pertama).
4. Upload seluruh isi folder ke Vercel / Netlify.
5. Jangan pisahkan folder assets dari index.html.

CATATAN KATALOG:
Saat ini baru ada 1 foto motor yang diberikan. Nama katalog sementara:
SUZUKI YELLOW TRAIL — BC/001.
Model/seri, tahun, kapasitas mesin, kondisi detail, harga, lokasi, dan dokumen
belum diberikan, jadi tidak dibuat-buat. Lengkapi informasi tersebut sebelum
website dipublikasikan dan konfirmasi ketersediaan unit sebelum transaksi.
